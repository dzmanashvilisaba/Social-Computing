#### CSS LAB 4 ####
#### Sampling distribution and inferential statistics ####

# In this lab, we will practice once more to understand how sampling distribution works step-by-step. 
# Let's say our population size is 10k and we measure the height of KAIST students. 
# The proportion of man is very high in KAIST, which will make the height distribution bimodal. 

# Let's create a hypothetical KAIST students height distribution. 
kaist_pop <- c(rnorm(8000, 175, 3), rnorm(2000, 160, 3)) 

# Question 1: Check its distribution using a histogram and describe its shape. 
# (CODE BY YOURSELF)

# Question 2: Check the population mean and standard deviation. 
# (CODE BY YOURSELF)

# Now, sample 100 students randomly from the population. 
sample <- sample(kaist_pop, 100, replace = FALSE)

# Question 3: Again, check its distribution using a histogram, and compute mean and sd, then compare them to your population distribution.
# If you're using RMarkdown and the composition of sample keeps changing whenever you run the code due to its randomness, you can set the random seed by using "set.seed(ANY NUMBERS)"
# CODE BY YOURSELF

# Now, let's repeat the same procedure for 1,000 times, and save their average.
sampling_distribution_n100 <- NULL # Create a vacant vector where we will save sampled means.

for (i in 1:1000) {
  sample_mean <- mean(sample(kaist_pop, 100, replace = FALSE))
  sampling_distribution_n100 <- c(sampling_distribution_n100, sample_mean)
}

# Question 4: Check the distribution of sampling distribution by using a histogram, and compute a mean and sd. 
# (continued) Describe the shape of distribution and compare it to the distribution from population. Do they look similar or not, and why?
# (continued) Describe the mean and standard deviation. Is it similar to population mean and standard deviation? 
# (CODE BY YOURSELF)

#### Confidence interval ####
# Let's again sample with size 100. 
sample_n100 <- sample(kaist_pop, 100, replace = FALSE)

# Question 5: Compute the mean and standard 'error'. Then, compute the 95% confidence interval. Explain the meaning of the confidence interval in English sentences.
# (CODE BY YOURSELF)

# Question 6: Does your confidence interval cover the 'true' mean? What does that mean? 

# Postech students randomly sample 30 students and find out that their average is 172.8. 
set.seed(1001)
sample_postech <- rnorm(30, 173, 3)

# Question 7: Does this sample support the argument that Postech students are statistically significantly taller than KAIST students?
# Use a t-test and examine this hypothesis and interpret the results. 
# (CODE BY YOURSELF)





